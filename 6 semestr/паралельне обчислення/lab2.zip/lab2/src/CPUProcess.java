public class CPUProcess
{

    public int lastingTime;
    public int id;

    public CPUProcess(int lastingTime, int id)
    {
        this.lastingTime = lastingTime;
        this.id = id;
    }

}